import React, { useState } from 'react';
const App = () => {
    const [name, setName] = useState('');
    const [greeting, setGreeting] = useState('');
    const handleGreet = () => {
        setGreeting(`Hello, ${name}! Welcome to the TypeScript React App.`);
    };
    return (React.createElement("div", null,
        React.createElement("h1", null, "React with TypeScript"),
        React.createElement("input", { type: "text", placeholder: "Enter your name", value: name, onChange: (e) => setName(e.target.value) }),
        React.createElement("button", { onClick: handleGreet }, "Greet"),
        React.createElement("p", null, greeting)));
};
export default App;
