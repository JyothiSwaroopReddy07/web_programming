import React, { useState } from 'react';

const App: React.FC = () => {
  const [name, setName] = useState<string>('');
  const [greeting, setGreeting] = useState<string>('');

  const handleGreet = () => {
    setGreeting(`Hello, ${name}! Welcome to the TypeScript React App.`);
  };

  return (
    <div>
      <h1>React with TypeScript</h1>
      <input
        type="text"
        placeholder="Enter your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={handleGreet}>Greet</button>
      <p>{greeting}</p>
    </div>
  );
};

export default App;
