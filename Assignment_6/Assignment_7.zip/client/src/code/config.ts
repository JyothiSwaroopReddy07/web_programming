export const config: { serverAddress: string, userEmail: string } =
{
  serverAddress : "http://localhost:8080",
  userEmail : "bjsreddy742002@gmail.com"
};
