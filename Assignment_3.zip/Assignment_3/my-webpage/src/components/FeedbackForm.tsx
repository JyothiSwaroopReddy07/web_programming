import React, { useState } from 'react';

const FeedbackForm: React.FC = () => {
  const [feedback, setFeedback] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Feedback Submitted: ${feedback}`);
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Feedback:
        <textarea
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
        />
      </label>
      <button type="submit">Submit</button>
    </form>
  );
};

export default FeedbackForm;
