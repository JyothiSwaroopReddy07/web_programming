import React from 'react';
import Header from './components/Header';
import Counter from './components/Counter';
import FeedbackForm from './components/FeedbackForm';

const App: React.FC = () => {
  return (
    <div>
      <Header />
      <main>
        <Counter />
        <FeedbackForm />
      </main>
    </div>
  );
};

export default App;
