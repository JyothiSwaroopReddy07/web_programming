
import React from "react";
import { User } from "../modules/userModule";

interface UserCardProps {
  user: User;
}

const UserCard: React.FC<UserCardProps> = ({ user }) => {
  return (
    <div style={{ border: "1px solid black", margin: "10px", padding: "10px" }}>
      <h3>{user.name}</h3>
      <p>Email: {user.email}</p>
    </div>
  );
};

export default UserCard;
