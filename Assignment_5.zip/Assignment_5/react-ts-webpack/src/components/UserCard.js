import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const UserCard = ({ user }) => {
    return (_jsxs("div", { style: { border: "1px solid black", margin: "10px", padding: "10px" }, children: [_jsx("h3", { children: user.name }), _jsxs("p", { children: ["Email: ", user.email] })] }));
};
export default UserCard;
