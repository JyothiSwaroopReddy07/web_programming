// src/namespaces/Shapes.ts
export var Shapes;
(function (Shapes) {
    class Circle {
        constructor(radius) {
            this.radius = radius;
        }
        area() {
            return Math.PI * this.radius * this.radius;
        }
    }
    Shapes.Circle = Circle;
    class Rectangle {
        constructor(width, height) {
            this.width = width;
            this.height = height;
        }
        area() {
            return this.width * this.height;
        }
    }
    Shapes.Rectangle = Rectangle;
})(Shapes || (Shapes = {}));
