// src/namespaces/Shapes.ts
export namespace Shapes {
    export interface Shape {
      area(): number;
    }
  
    export class Circle implements Shape {
      constructor(public radius: number) {}
      area(): number {
        return Math.PI * this.radius * this.radius;
      }
    }
  
    export class Rectangle implements Shape {
      constructor(public width: number, public height: number) {}
      area(): number {
        return this.width * this.height;
      }
    }
  }
  