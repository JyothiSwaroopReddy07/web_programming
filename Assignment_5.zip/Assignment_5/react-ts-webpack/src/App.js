import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Calculator } from "./modules/mathUtils";
import { Shapes } from "./namespaces/Shapes";
import { UserManager } from "./modules/userModule";
import UserCard from "./components/UserCard";
const App = () => {
    // Using the Calculator module
    const calc = new Calculator();
    const sum = calc.add(10, 20);
    // Using the Shapes namespace
    const circle = new Shapes.Circle(5);
    const rectangle = new Shapes.Rectangle(4, 6);
    // Using UserManager with Decorators
    const userManager = new UserManager();
    const users = [
        { id: 1, name: "Alice", email: "alice@example.com" },
        { id: 2, name: "Bob", email: "bob@example.com" },
    ];
    users.forEach((user) => userManager.addUser(user));
    return (_jsx(_Fragment, { children: _jsxs("div", { children: [_jsx("h1", { children: "Advanced TypeScript Features" }), _jsx("h2", { children: "Math Utilities" }), _jsxs("p", { children: ["10 + 20 = ", sum] }), _jsx("h2", { children: "Shapes" }), _jsxs("p", { children: ["Circle Area (radius 5): ", circle.area().toFixed(2)] }), _jsxs("p", { children: ["Rectangle Area (4 x 6): ", rectangle.area()] }), _jsx("h2", { children: "Users" }), userManager.getUsers().map((user) => (_jsx(UserCard, { user: user }, user.id)))] }) }));
};
export default App;
