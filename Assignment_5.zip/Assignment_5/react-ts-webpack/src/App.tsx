// src/App.tsx
import React from "react";
import { Calculator } from "./modules/mathUtils";
import { Shapes } from "./namespaces/Shapes";
import { UserManager, User } from "./modules/userModule";
import UserCard from "./components/UserCard";

const App: React.FC = () => {
  // Using the Calculator module
  const calc = new Calculator();
  const sum = calc.add(10, 20);

  // Using the Shapes namespace
  const circle = new Shapes.Circle(5);
  const rectangle = new Shapes.Rectangle(4, 6);

  // Using UserManager with Decorators
  const userManager = new UserManager();
  const users: User[] = [
    { id: 1, name: "Alice", email: "alice@example.com" },
    { id: 2, name: "Bob", email: "bob@example.com" },
  ];
  users.forEach((user) => userManager.addUser(user));

  return (
    <>
      <div>
        <h1>Advanced TypeScript Features</h1>

        <h2>Math Utilities</h2>
        <p>10 + 20 = {sum}</p>

        <h2>Shapes</h2>
        <p>Circle Area (radius 5): {circle.area().toFixed(2)}</p>
        <p>Rectangle Area (4 x 6): {rectangle.area()}</p>

        <h2>Users</h2>
        {userManager.getUsers().map((user) => (
          <UserCard key={user.id} user={user} />
        ))}
      </div>
    </>
  );
};

export default App;
