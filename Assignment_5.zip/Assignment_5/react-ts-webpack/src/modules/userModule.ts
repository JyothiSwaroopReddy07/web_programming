// src/modules/userModule.ts
import { Logger } from "../decorators/Logger";

export interface User {
  id: number;
  name: string;
  email: string;
}

@Logger("UserManager Initialized")
export class UserManager {
  private users: User[] = [];

  addUser(user: User) {
    this.users.push(user);
    console.log("User added:", user);
  }

  getUsers(): User[] {
    return this.users;
  }
}
