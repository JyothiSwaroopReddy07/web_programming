export function Logger(message) {
    return function (constructor) {
        console.log(`${message}: ${constructor.name}`);
    };
}
